package com.cg.exception;

public class JdbcException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public JdbcException() {
		super();
	}
	
	public JdbcException(String message ) {
		super(message);
	}
}

package com.cg.beans;

public class Account {
	
	private int accountNumber;
	private String insuredHolderName;
	private String insuredHolderStreet;
	private String insuredHolderCity;
	private String insuredHolderState;
	private int insuredPincode;
	private String businessType;
	private String userName;
	
	public Account() {
		
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getInsuredHolderName() {
		return insuredHolderName;
	}

	public void setInsuredHolderName(String insuredHolderName) {
		this.insuredHolderName = insuredHolderName;
	}

	public String getInsuredHolderStreet() {
		return insuredHolderStreet;
	}

	public void setInsuredHolderStreet(String insuredHolderStreet) {
		this.insuredHolderStreet = insuredHolderStreet;
	}

	public String getInsuredHolderCity() {
		return insuredHolderCity;
	}

	public void setInsuredHolderCity(String insuredHolderCity) {
		this.insuredHolderCity = insuredHolderCity;
	}

	public String getInsuredHolderState() {
		return insuredHolderState;
	}

	public void setInsuredHolderState(String insuredHolderState) {
		this.insuredHolderState = insuredHolderState;
	}

	public int getInsuredPincode() {
		return insuredPincode;
	}

	public void setInsuredPincode(int insuredPincode) {
		this.insuredPincode = insuredPincode;
	}

	public String getBusinessType() {
		return businessType;
	}

	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	
}
package com.cg.jdbc;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import com.cg.exception.JdbcException;

public class JdbcConfigure {
	private static final String USERNAME="System";
	private static final String PASSWORD="India@123";
	private static final String URL="jdbc:oracle:thin:@localhost:1521:XE";
	private static final String DRIVER="oracle.jdbc.OracleDriver";
	private static Connection connection = null;

	public static Connection getConnection() throws JdbcException {

		
		
		try {

			Class.forName(DRIVER);
			connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);

		} catch (ClassNotFoundException e) {
			throw new JdbcException("class not loaded");
		} catch (SQLException e) {
			throw new JdbcException("connection issue");
		} 
		

		return connection;
	}

}

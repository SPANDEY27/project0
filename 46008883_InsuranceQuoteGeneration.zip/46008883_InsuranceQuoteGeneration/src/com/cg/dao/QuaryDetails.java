package com.cg.dao;

public class QuaryDetails {

	public static final String logIn = "select * from UserDetail where user_name=? and password=?";
	
	public static final String InsertData="insert into Account values(acc_seq.nextval,?,?,?,?,?,?,?)";
	
	public static final String getAccountNumber="select acc_seq.currval from dual";
	
	public static final String getUser="select * from Account where user_name=?";
	
	public static final String createProfile="INSERT INTO UserDetail values(?,?,?)";
	
	public static final String getBuisnessSegment="SELECT * FROM Account WHERE accountNumber=?";
		
	public static final String insertInPolicy = "INSERT INTO policy values(policy_number_seq.nextval, ?, ?)";
	
	public static final String getPolicyNumber ="select policy_number_seq.currval from dual";
	
	public static final String insertPolicyDetails="INSERT INTO PolicyDetails VALUES(?,?,?)";
	
	public static final String validAccountNumber="SELECT * FROM Account";
	
	public static final String getPolicyDetails="SELECT * FROM PolicyBean";
	
	public static final String getPolicy="select p.policy_number,p.policy_premium,a.account_number from Account a, policy p where a.account_number=p.account_number and a.user_name=?";

}

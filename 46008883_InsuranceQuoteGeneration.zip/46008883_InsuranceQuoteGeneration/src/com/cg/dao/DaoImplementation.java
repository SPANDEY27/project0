package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;



import com.cg.beans.Account;
import com.cg.beans.PolicyBean;
import com.cg.beans.PolicyDetails;
import com.cg.beans.UserDetails;
import com.cg.exception.IOException;
import com.cg.exception.JdbcException;
import com.cg.jdbc.JdbcConfigure;


public class DaoImplementation implements DaoLayer {
	
	Connection connection = null;
	PreparedStatement statement = null;
	
	@Override
	public String validLogIn(UserDetails details) throws IOException {
		ResultSet resultSet = null;
		String result=null;
		
		try {
			connection = JdbcConfigure.getConnection();
			try {
				statement=connection.prepareStatement(QuaryDetails.logIn);
				statement.setString(1, details.getUserName());
				statement.setString(2, details.getPassword());
				
				resultSet=statement.executeQuery();
				while(resultSet.next()) {
					String userName=resultSet.getString(1);
					String passWord=resultSet.getString(2);
					if(details.getUserName().equals(userName)&&passWord.equals(details.getPassword())) {
						result=resultSet.getString(3);
						break;
					}
				}
			} catch (SQLException e) {
				throw new IOException("Unable to fatch Result, There is Some sql Error");
			}
		} catch (JdbcException e) {
			throw new IOException("Unable to fatch Result, There is Some JDBC related Error");
		} finally {
			try {
				resultSet.close();
			} catch (SQLException e) {
				throw new IOException("Unable to close ResultSet Object, There is Some Error");
			}
			try {
				statement.close();
			} catch (SQLException e) {
				throw new IOException("Unable to Close Statement Object, There is Some Error");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				throw new IOException("Unable to close Connection Object, There is Some Error");
			}
		}
		return result;
	}

	@Override
	public int createAccount(Account accounts) throws IOException {
		ResultSet resultSet=null;
		
		
		return 0;
	}

	@Override
	public boolean getUserName(String userName) throws IOException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int addProfile(UserDetails role) throws IOException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean existAccount(int accountNumber) throws IOException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getBuisnessSegment(int accountNumber) throws IOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getBuisnessSegmentId(String businessSegment) throws IOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> getQuestions(String buisnessSegId) throws IOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> getAnswer(String string) throws IOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getWeightage(String string, String option) throws IOException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int insertPolicy(PolicyBean policy) throws IOException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getQuesId(String question) throws IOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> getQuestionId(String buisnessSegId) throws IOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insertPolicyDetails(PolicyDetails policyDetails) throws IOException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<PolicyBean> viewPolicyDetails() throws IOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PolicyDetails getPolicy(String userName) throws IOException {
		// TODO Auto-generated method stub
		return null;
	}

}

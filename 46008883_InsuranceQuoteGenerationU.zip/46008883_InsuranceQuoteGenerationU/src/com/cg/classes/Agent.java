package com.cg.classes;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.beans.PolicyBean;
import com.cg.exception.IOException;
import com.cg.service.InsuranceService;
import com.cg.service.InsuranceServiceImpl;
import com.cg.support.CreateAccount;
import com.cg.support.DisplayPolicy;
import com.cg.support.GenerateReport;
import com.cg.support.PolicyCreation;
import com.cg.support.ProfileCreation;

public class Agent {
	
	CreateAccount accountCreation = new CreateAccount();
	InsuranceService service = new InsuranceServiceImpl();
	ProfileCreation profileCreation = new ProfileCreation();
	PolicyCreation createPolicy = new PolicyCreation();
	GenerateReport generateReport = new GenerateReport();
	
	public void agent() {
		Scanner scanner = null;
		int choice = 0;
		boolean choiceFlag = false;
		do {
			scanner = new Scanner(System.in);
			System.out.println("1.Create Account");
			System.out.println("2.Policy creation");
			System.out.println("3.View policy");
			System.out.println("4.Exit");
			System.out.println();
			System.out.println("Enter choice: ");

			try {
				choice = scanner.nextInt();
				choiceFlag = true;
				switch (choice) {
				case 1:
					try {
						System.out.println("Enter the UserName to create Account");
						String userName=scanner.next();
						int accountNumber = accountCreation.createAccount(userName);
						System.out.println("Account created with account number " + accountNumber);
						/*
						 * boolean continueFlag = false; do { scanner=new Scanner(System.in);
						 * System.out.println("Do you want to still continue (Y/N): "); String wish =
						 * scanner.next(); wish = wish.toLowerCase(); if (wish.equals("y")) {
						 * 
						 * choiceFlag = false; continueFlag = true; } else { if (wish.equals("n")) {
						 * choiceFlag = true; continueFlag = true; } else { choiceFlag = true;
						 * continueFlag = false; System.err.println("Enter Y or N."); } } } while
						 * (!continueFlag);
						 */
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}
					break;
				case 2:
					boolean accountFlag = false;
					int accountNumber = 0;
					// int premiumNumber = 0;
					do {
						scanner = new Scanner(System.in);
						System.out.println("Enter account number for which you want to create policy: ");
						try {
							accountNumber = scanner.nextInt();
							try {
								
									boolean existAccount = service.existAccount(accountNumber);
									if (existAccount) {
										createPolicy.createPolicy(accountNumber);
										//scanner.nextLine();
									} else {
										System.err.println("Account number does not exist.....");
									}
									boolean continueFlag = false;
									do {
										//scanner = new Scanner(System.in);
										System.out.println("Do you want to still continue (Y/N): ");
										//Scanner scanner1 = new Scanner(System.in);
										scanner = new Scanner(System.in);
										String wish="";
										wish = scanner.nextLine();
										System.out.println(wish+"najaj");
										wish = wish.toLowerCase();
										if (wish.equals("y")) {

											choiceFlag = false;
											continueFlag = true;
										} else {
											if (wish.equals("n")) {
												choiceFlag = true;
												continueFlag = true;
											} else {
												choiceFlag = true;
												continueFlag = false;
												System.err.println("Enter Y or N.");
											}
										}
									} while (!continueFlag);
								} 
							 catch (IOException e) {
								System.err.println(e.getMessage());
							}
							// int policynumber=service.createPolicy();
						} catch (InputMismatchException e) {
							System.err.println("Enter digits only...");
							accountFlag = false;
						}
					} while (!accountFlag);
					break;
				case 3:
					DisplayPolicy viewPolicy = new DisplayPolicy();
					List<PolicyBean> list = new ArrayList<>();
					try {

						list = viewPolicy.viewPolicyDetails();
						if (!list.isEmpty()) {
							System.out.println("*************Policy View*******************");
							String format = String.format("%-20s %-20s %s", "Policy Number", "Premium Amount",
									"Account Number");
							System.out.println(format);
							for (PolicyBean policy : list) {
								System.out.println(String.format("%-20s %-20s %s", policy.getPolicyNumber(),
										policy.getPolicyPremium(), policy.getAccountNumber()));
							}
						} else {
							System.out.println("No data Found...");
						}
						boolean continueFlag = false;
						do {
							System.out.println("Do you want to still continue (Y/N): ");
							String wish = scanner.next();
							wish = wish.toLowerCase();
							if (wish.equals("y")) {

								choiceFlag = false;
								continueFlag = true;
							} else {
								if (wish.equals("n")) {
									choiceFlag = true;
									continueFlag = true;
								} else {
									choiceFlag = true;
									continueFlag = false;
									System.err.println("Enter Y or N.");
								}
							}
						} while (!continueFlag);

					} catch (IOException e) {
						System.err.println(e.getMessage());
						choiceFlag = false;
					}
					break;
				case 4:
					System.out.println("Thank you visit again");
					System.exit(0);
				default:
					System.err.println("Enter choice (1-4)");
					choiceFlag = false;
					break;
				}
			} catch (InputMismatchException e) {
				System.err.println("Enter digits only..");
				choiceFlag = false;
			}

		} while (!choiceFlag);
		System.out.println("Thank you visit again");
		scanner.close();
	}
}

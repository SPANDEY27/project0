package com.cg.classes;


import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.beans.PolicyBean;
import com.cg.exception.IOException;
import com.cg.service.InsuranceService;
import com.cg.service.InsuranceServiceImpl;
import com.cg.support.CreateAccount;
import com.cg.support.DisplayPolicy;

public class Insurance {
	
	CreateAccount accountCreation = new CreateAccount();
	DisplayPolicy viewPolicy = new DisplayPolicy();
	
	public void Insurance() {
		Scanner scanner = null;
		InsuranceService service = new InsuranceServiceImpl();
		int choice = 0;
		boolean choiceFlag = false;
		do {
			scanner = new Scanner(System.in);
			System.out.println("1.Create Account");
			System.out.println("2.View Policy");
			System.out.println();
			System.out.println("Enter Choice: ");
			try {
				choice = scanner.nextInt();
				if (choice == 1) {
					System.out.println("Enter the UserName");
					String userName=scanner.next();
					boolean exist = service.getUserName(userName);
					System.out.println("Your account is already created....");
					if (exist == true) {
						boolean continueFlag = false;
						do {
							System.out.println("Do you want to still continue (Y/N): ");
							String wish = scanner.next();
							wish = wish.toLowerCase();
							if (wish.equals("y")) {

								choiceFlag = false;
								continueFlag = true;
							} else {
								if (wish.equals("n")) {
									choiceFlag = true;
									continueFlag = true;
								} else {
									choiceFlag = true;
									continueFlag = false;
									System.err.println("Enter Y or N.");
								}
							}
						} while (!continueFlag);
					}

				}

				else if (choice == 2) {
					PolicyBean policy = null;
					DisplayPolicy viewPolicy = new DisplayPolicy();
					try {
						System.out.println("Enter the UserName");
						String userName=scanner.next();
						policy = viewPolicy.getPolicy(userName);

						System.out.println("*************Policy View*******************");
						String format = String.format("%-20s %-20s %s", "Policy Number", "Premium Amount",
								"Account Number");
						System.out.println(format);
						System.out.println(String.format("%-20s %-20s %s", policy.getPolicyNumber(),
								policy.getPolicyPremium(), policy.getAccountNumber()));

					} catch (IOException e) {
						System.err.println(e.getMessage());
					}

					boolean continueFlag = false;
					do {
						System.out.println("Do you want to still continue (Y/N): ");
						String wish = scanner.next();
						wish = wish.toLowerCase();
						if (wish.equals("y")) {

							choiceFlag = false;
							continueFlag = true;
						} else {
							if (wish.equals("n")) {
								choiceFlag = true;
								continueFlag = true;
							} else {
								choiceFlag = true;
								continueFlag = false;
								System.err.println("Enter Y or N.");
							}
						}
					} while (!continueFlag);

				} else {
					System.out.println("Enter choice (1-2)");
					choiceFlag = false;

				}

			} catch (InputMismatchException e) {
				System.err.println("Enter digits only....");
				choiceFlag = false;
			} catch (Exception e) {
				System.out.println("Enter the UserName");
				String userName=scanner.next();
				int accountNumber = accountCreation.createAccount(userName);
				System.out.println("Account created with account number: " + accountNumber);
				boolean continueFlag = false;
				do {
					System.out.println("Do you want to still continue (Y/N): ");
					String wish = scanner.next();
					wish = wish.toLowerCase();
					if (wish.equals("y")) {

						choiceFlag = false;
						continueFlag = true;
					} else {
						if (wish.equals("n")) {
							choiceFlag = true;
							continueFlag = true;
						} else {
							choiceFlag = true;
							continueFlag = false;
							System.err.println("Enter Y or N.");
						}
					}
				} while (!continueFlag);
			}

		} while (!choiceFlag);
		scanner.close();
	}

}

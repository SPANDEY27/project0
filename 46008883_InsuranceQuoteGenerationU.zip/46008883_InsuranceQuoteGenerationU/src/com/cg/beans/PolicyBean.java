package com.cg.beans;

public class PolicyBean {

	private int policyNumber;
	private double policyPremium;
	private int accountNumber;
	
	
	public PolicyBean(int policyNumber, double policyPremium, int accountNumber) {
		super();
		this.policyNumber = policyNumber;
		this.policyPremium = policyPremium;
		this.accountNumber = accountNumber;
	}

	public int getPolicyNumber() {
		return policyNumber;
	}
	public PolicyBean(Double policyPremium, Integer accountNumber) {
		super();
		this.policyPremium = policyPremium;
		this.accountNumber = accountNumber;
	}


	public void setPolicyNumber(int policyNumber) {
		this.policyNumber = policyNumber;
	}

	public double getPolicyPremium() {
		return policyPremium;
	}

	public void setPolicyPremium(double policyPremium) {
		this.policyPremium = policyPremium;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	
	
	
}

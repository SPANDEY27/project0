package com.cg.beans;

public class PolicyGeneration {
	private String policyHolderName;
	private String holderStreet;
	private String holderCity;
	private String holderState;
	private Integer holderPinCode;
	private String holderBusinessSegment;
	private String policyQuestion;
	private String policyAnswer;
	private Double policyPremium;
	public PolicyGeneration() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PolicyGeneration(String policyHolderName, String holderStreet, String holderCity, String holderState,
			Integer holderPinCode, String holderBusinessSegment, String policyQuestion, String policyAnswer,
			Double policyPremium) {
		super();
		this.policyHolderName = policyHolderName;
		this.holderStreet = holderStreet;
		this.holderCity = holderCity;
		this.holderState = holderState;
		this.holderPinCode = holderPinCode;
		this.holderBusinessSegment = holderBusinessSegment;
		this.policyQuestion = policyQuestion;
		this.policyAnswer = policyAnswer;
		this.policyPremium = policyPremium;
	}
	public String getPolicyHolderName() {
		return policyHolderName;
	}
	public void setPolicyHolderName(String policyHolderName) {
		this.policyHolderName = policyHolderName;
	}
	public String getHolderStreet() {
		return holderStreet;
	}
	public void setHolderStreet(String holderStreet) {
		this.holderStreet = holderStreet;
	}
	public String getHolderCity() {
		return holderCity;
	}
	public void setHolderCity(String holderCity) {
		this.holderCity = holderCity;
	}
	public String getHolderState() {
		return holderState;
	}
	public void setHolderState(String holderState) {
		this.holderState = holderState;
	}
	public Integer getHolderPinCode() {
		return holderPinCode;
	}
	public void setHolderPinCode(Integer holderPinCode) {
		this.holderPinCode = holderPinCode;
	}
	public String getHolderBusinessSegment() {
		return holderBusinessSegment;
	}
	public void setHolderBusinessSegment(String holderBusinessSegment) {
		this.holderBusinessSegment = holderBusinessSegment;
	}
	public String getPolicyQuestion() {
		return policyQuestion;
	}
	public void setPolicyQuestion(String policyQuestion) {
		this.policyQuestion = policyQuestion;
	}
	public String getPolicyAnswer() {
		return policyAnswer;
	}
	public void setPolicyAnswer(String policyAnswer) {
		this.policyAnswer = policyAnswer;
	}
	public Double getPolicyPremium() {
		return policyPremium;
	}
	public void setPolicyPremium(Double policyPremium) {
		this.policyPremium = policyPremium;
	}
	
	
	
	
}

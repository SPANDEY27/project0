package com.cg.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.beans.UserDetails;
import com.cg.classes.Admin;
import com.cg.classes.Agent;
import com.cg.classes.Insurance;
import com.cg.exception.IOException;
import com.cg.service.InsuranceService;
import com.cg.service.InsuranceServiceImpl;



public class InsuranceMain {
	
	public static void main(String[] args) {
		Insurance insured=new Insurance();
		Admin admin=new Admin();
		Agent agent=new Agent();
		InsuranceService service=new InsuranceServiceImpl();
		System.out.println("Insurance Quote Generation System");
		Scanner scanner = null;

		boolean choiceFlag = false;
		do {

			scanner = new Scanner(System.in);
			System.out.println("1. General Login");
			System.out.println("2. Admin Section");
			System.out.println("3. Agent Section");
			System.out.println("4. Insurance Section");
			System.out.println("5. Exit");
			System.out.println("Enter choice: ");
			int input = 0;
			try {
				input = scanner.nextInt();
				choiceFlag = true;
				switch (input) {
				case 1:
					scanner.nextLine();
					String userName = "";
					String password = "";
					String validUser = "";
					System.out.println("Enter Username: ");
					userName = scanner.nextLine();
					System.out.println("Enter password: ");
					password = scanner.nextLine();
					UserDetails role = new UserDetails(userName, password);
					try {
						validUser = service.validUser(role);
						if (validUser == null) {
							System.err.println("User not found");
						} else {
							System.out.println("You are logged in as " + validUser);
							// System.out.println(validUser);
							validUser = validUser.trim();
							if (validUser.equals("Insured")) {
								insured.Insurance();
								// System.out.println(userFlag);

							} else if (validUser.equals("Agent")) {
								agent.agent();
							} else {
								admin.admin();
							}
						}
					} catch (IOException e) {
						System.err.println(e.getMessage());
					}
					break;
				case 2:	String userName1=null;
					System.out.println("WelCome to Admin Section ");
					admin.admin();
					break;
				case 3: 
					System.out.println("Welcome to Agent Section ");
					agent.agent();
				case 4: 
					System.out.println("Welcome to Insurance Section ");
					insured.Insurance();
				default:
					System.out.println("Entered wrong Choice, Try again Later...");
					break;
				}

			} catch (InputMismatchException e) {

				System.err.println("Enter only digits");
				choiceFlag = false;
			}

		} while (!choiceFlag);
		scanner.close();
	}

	}


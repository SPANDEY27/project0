package com.cg.exception;

public class IOException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public IOException() {
		super();
	}
	public IOException(String message) {
		super(message);
	}
}

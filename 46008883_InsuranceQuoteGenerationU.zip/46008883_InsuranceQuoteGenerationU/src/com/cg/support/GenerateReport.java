package com.cg.support;

import java.util.List;

import com.cg.beans.PolicyGeneration;
import com.cg.exception.IOException;
import com.cg.service.InsuranceService;
import com.cg.service.InsuranceServiceImpl;


public class GenerateReport {

	InsuranceService insuranceService= new InsuranceServiceImpl();

	public List<PolicyGeneration> generateReport(int accountNumber1) throws IOException{
		return insuranceService.generateReport(accountNumber1);
}
}

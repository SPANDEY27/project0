package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.beans.Account;
import com.cg.beans.PolicyBean;
import com.cg.beans.PolicyDetails;
import com.cg.beans.PolicyGeneration;
import com.cg.beans.UserDetails;
import com.cg.exception.IOException;
import com.cg.exception.JdbcException;
import com.cg.jdbc.JdbcConfigure;

public class DaoImplementation implements DaoLayer {

	Connection connection = null;
	PreparedStatement statement = null;

	@Override
	public String validLogIn(UserDetails details) throws IOException {
		ResultSet resultSet = null;
		String result = null;

		try {
			connection = JdbcConfigure.getConnection();
			try {
				statement = connection.prepareStatement(QuaryDetails.logIn);
				statement.setString(1, details.getUserName());
				statement.setString(2, details.getPassword());

				resultSet = statement.executeQuery();
				while (resultSet.next()) {
					String userName = resultSet.getString(1);
					String passWord = resultSet.getString(2);
					if (details.getUserName().equals(userName) && passWord.equals(details.getPassword())) {
						result = resultSet.getString(3);
						break;
					}
				}
			} catch (SQLException e) {
				throw new IOException("Unable to fatch Result, There is Some sql Error");
			}
		} catch (JdbcException e) {
			throw new IOException("Unable to fatch Result, There is Some JDBC related Error");
		} finally {
			try {
				resultSet.close();
			} catch (SQLException e) {
				throw new IOException("Unable to close ResultSet Object, There is Some Error");
			}
			try {
				statement.close();
			} catch (SQLException e) {
				throw new IOException("Unable to Close Statement Object, There is Some Error");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				throw new IOException("Unable to close Connection Object, There is Some Error");
			}
		}
		return result;
	}

	@Override
	public int createAccount(Account accounts) throws IOException {
		int accountNumber = 0;
		ResultSet resultSet = null;
		try {
			connection = JdbcConfigure.getConnection();
			statement = connection.prepareStatement(QuaryDetails.InsertData);
			statement.setString(1, accounts.getInsuredHolderName());
			statement.setString(2, accounts.getInsuredHolderStreet());
			statement.setString(3, accounts.getInsuredHolderCity());
			statement.setString(4, accounts.getInsuredHolderState());
			statement.setString(5, accounts.getBusinessType());
			statement.setString(6, accounts.getUserName());
			statement.executeUpdate();

			statement = connection.prepareStatement(QuaryDetails.getAccountNumber);
			resultSet = statement.executeQuery();
			resultSet.next();

			accountNumber = resultSet.getInt(1);
			connection.commit();
		} catch (JdbcException | SQLException e) {

			try {
				connection.rollback();
			} catch (SQLException e1) {
				throw new IOException("There is an Error with Sql Exception");
			}
			throw new IOException("There is an Error with Jdbc or Sql Exception");
		} finally {
			try {
				resultSet.close();
			} catch (SQLException e) {
				throw new IOException("Unable to close ResultSet Object, There is Some Error");
			}
			try {
				statement.close();
			} catch (SQLException e) {
				throw new IOException("Unable to Close Statement Object, There is Some Error");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				throw new IOException("Unable to close Connection Object, There is Some Error");
			}
		}

		return accountNumber;
	}

	@Override
	public boolean getUserName(String userName) throws IOException {
		boolean userFlag = false;
		ResultSet resultSet = null;

		try {
			connection = JdbcConfigure.getConnection();
			statement = connection.prepareStatement(QuaryDetails.getUser);
			statement.setString(1, userName);
			resultSet = statement.executeQuery();
			resultSet.next();

			String UserName1 = resultSet.getString(8);
			if (userName.equals(UserName1)) {
				userFlag = true;
			}
		} catch (JdbcException | SQLException e) {
			throw new IOException("There is an Error with Jdbc or Sql Exception");

		} finally {
			try {
				resultSet.close();
			} catch (SQLException e) {
				throw new IOException("Unable to close ResultSet Object, There is Some Error");
			}
			try {
				statement.close();
			} catch (SQLException e) {
				throw new IOException("Unable to Close Statement Object, There is Some Error");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				throw new IOException("Unable to close Connection Object, There is Some Error");
			}
		}
		return false;
	}

	@Override
	public int addProfile(UserDetails role) throws IOException {
		int detail = 0;

		try {
			connection = JdbcConfigure.getConnection();

			statement = connection.prepareStatement(QuaryDetails.createProfile);

			statement.setString(1, role.getUserName());
			statement.setString(2, role.getPassword());
			statement.setString(3, role.getRoleCode());

			detail = statement.executeUpdate();

		} catch (JdbcException | SQLException e) {
			throw new IOException("Unable to Create new Profile");
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				throw new IOException("Unable to Close Statement Object, There is Some Error");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				throw new IOException("Unable to close Connection Object, There is Some Error");
			}
		}
		return 0;
	}

	@Override
	public boolean existAccount(int accountNumber) throws IOException {
		boolean accountValid = false;
		ResultSet resultSet = null;
		try {
			connection = JdbcConfigure.getConnection();
			statement = connection.prepareStatement(QuaryDetails.validAccountNumber);
			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				if (accountNumber == resultSet.getInt(1)) {
					accountValid = true;
					break;
				}
			}
		} catch (JdbcException | SQLException e) {
			throw new IOException("Unable to Fatch Data");
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				throw new IOException("Unable to Close Statement Object, There is Some Error");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				throw new IOException("Unable to close Connection Object, There is Some Error");
			}
		}

		return accountValid;
	}

	@Override
	public String getBuisnessSegment(int accountNumber) throws IOException {
		String businessSegment = "";
		ResultSet resultSet = null;
		try {
			connection = JdbcConfigure.getConnection();
			statement = connection.prepareStatement(QuaryDetails.getBuisnessSegment);
			statement.setInt(1, accountNumber);
			resultSet = statement.executeQuery();

			resultSet.next();

			businessSegment = resultSet.getString(7);
		} catch (JdbcException | SQLException e) {
			throw new IOException("Unable to Fatch Data");
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				throw new IOException("Unable to Close Statement Object, There is Some Error");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				throw new IOException("Unable to close Connection Object, There is Some Error");
			}
		}
		return businessSegment;
	}

	@Override
	public List<String> getQuestions(String buisnessSegId) throws IOException {
		List<String> questionList = new ArrayList<>();
		ResultSet resultSet = null;
		try {
			connection = JdbcConfigure.getConnection();
			statement = connection.prepareStatement(QuaryDetails.getQuestions);
			statement.setString(1, buisnessSegId);

			resultSet = statement.executeQuery();

			while (resultSet.next()) {
				questionList.add(resultSet.getString(4));
			}
		} catch (JdbcException | SQLException e) {
			throw new IOException("Unable to fetch Questions" + e.getMessage());
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				throw new IOException("Unable to Close Statement Object, There is Some Error");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				throw new IOException("Unable to close Connection Object, There is Some Error");
			}
		}

		return questionList;
	}

	@Override
	public List<String> getAnswer(String string) throws IOException {
		List<String> answerList = new ArrayList<>();
		ResultSet resultSet = null;
		String ans1 = "";
		String ans2 = "";
		String ans3 = "";

		try {
			connection = JdbcConfigure.getConnection();
			statement = connection.prepareStatement(QuaryDetails.getAnswer);
			statement.setString(1, string);

			resultSet = statement.executeQuery();
			while (resultSet.next()) {
				ans1 = resultSet.getString(5);
				answerList.add(ans1);
				ans1 = resultSet.getString(7);
				answerList.add(ans2);
				ans1 = resultSet.getString(9);
				answerList.add(ans3);
			}
		} catch (JdbcException | SQLException e) {
			throw new IOException("Unable to fetch Questions" + e.getMessage());
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				throw new IOException("Unable to Close Statement Object, There is Some Error");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				throw new IOException("Unable to close Connection Object, There is Some Error");
			}
		}
		return answerList;
	}

	@Override
	public int getWeightage(String string, String option) throws IOException {
		ResultSet resultSet = null;
		int premium = 0;
		try {
			connection = JdbcConfigure.getConnection();
			statement = connection.prepareStatement(QuaryDetails.getAnswer);
			statement.setString(1, string);
			resultSet = statement.executeQuery();
			resultSet.next();
			int column = 5;

			while (column <= 9) {
				if (resultSet.getString(column).equals(option)) {
					premium = resultSet.getInt(column + 1);
					break;
				}
				column = column + 2;
			}
		} catch (JdbcException | SQLException e) {
			throw new IOException("Unable to fetch Data" + e.getMessage());
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				throw new IOException("Unable to Close Statement Object, There is Some Error");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				throw new IOException("Unable to close Connection Object, There is Some Error");
			}
		}

		return premium;
	}

	@Override
	public int insertPolicy(PolicyBean policy) throws IOException {
		int policyNumber = 0;
		ResultSet resultSet = null;
		try {
			connection = JdbcConfigure.getConnection();
			statement = connection.prepareStatement(QuaryDetails.insertInPolicy);
			statement.setDouble(1, policy.getPolicyPremium());
			statement.setInt(2, policy.getAccountNumber());
			statement.executeUpdate();

			statement = connection.prepareStatement(QuaryDetails.getPolicyNumber);
			resultSet = statement.executeQuery();
			resultSet.next();

			policyNumber = resultSet.getInt(1);
			connection.commit();
		} catch (JdbcException | SQLException e) {
			throw new IOException("Unable to fetch Data" + e.getMessage());

		} finally {
			try {
				resultSet.close();
			} catch (SQLException e) {
				throw new IOException("Unable to close ResultSet Object, There is Some Error");
			}
			try {
				statement.close();
			} catch (SQLException e) {
				throw new IOException("Unable to Close Statement Object, There is Some Error");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				throw new IOException("Unable to close Connection Object, There is Some Error");
			}
		}
		return policyNumber;
	}

	@Override
	public String getQuesId(String question) throws IOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> getQuestionId(String buisnessSegId) throws IOException {
		List<String> questionIdList = new ArrayList<>();
		ResultSet resultSet = null;

		try {
			connection = JdbcConfigure.getConnection();

			statement = connection.prepareStatement(QuaryDetails.getQuestions);
			statement.setString(1, buisnessSegId);
			resultSet = statement.executeQuery();

			while (resultSet.next()) {
				questionIdList.add(resultSet.getString(1));
			}
		} catch (JdbcException | SQLException e) {
			throw new IOException("Unable to fetch Data" + e.getMessage());
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				throw new IOException("Unable to Close Statement Object, There is Some Error");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				throw new IOException("Unable to close Connection Object, There is Some Error");
			}
		}

		return questionIdList;
	}

	@Override
	public void insertPolicyDetails(PolicyDetails policyDetails) throws IOException {
		try {
			connection = JdbcConfigure.getConnection();
			statement = connection.prepareStatement(QuaryDetails.insertPolicyDetails);
			statement.setInt(1, policyDetails.getPolicyNumber());
			statement.setString(2, policyDetails.getQuestionID());
			statement.setString(3, policyDetails.getAnswer());

			statement.executeUpdate();

			connection.commit();
		} catch (JdbcException | SQLException e) {
			throw new IOException("Unable to fetch Data" + e.getMessage());
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				throw new IOException("Unable to Close Statement Object, There is Some Error");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				throw new IOException("Unable to close Connection Object, There is Some Error");
			}
		}

	}

	@Override
	public List<PolicyBean> viewPolicyDetails() throws IOException {

		List<PolicyBean> viewPolicy = new ArrayList<>();
		ResultSet resultSet = null;

		try {
			connection = JdbcConfigure.getConnection();

			statement = connection.prepareStatement(QuaryDetails.getPolicyDetails);

			resultSet = statement.executeQuery();

			while (resultSet.next()) {
				int policyNumber = resultSet.getInt(1);
				double policyPremium = resultSet.getDouble(2);
				int accountNumber = resultSet.getInt(3);
			}
		} catch (JdbcException | SQLException e) {
			throw new IOException("Unable to fetch Data" + e.getMessage());
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				throw new IOException("Unable to Close Statement Object, There is Some Error");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				throw new IOException("Unable to close Connection Object, There is Some Error");
			}
		}

		return viewPolicy;
	}

	@Override
	public PolicyBean getPolicy(String userName) throws IOException {
		PolicyBean policy = null;
		ResultSet resultSet = null;

		try {
			connection = JdbcConfigure.getConnection();
			statement = connection.prepareStatement(QuaryDetails.getPolicy);
			statement.setString(1, userName);

			resultSet = statement.executeQuery();

			resultSet.next();
			int policyNumber = resultSet.getInt(1);
			double policyPremium = resultSet.getDouble(2);
			int accountNumber = resultSet.getInt(3);

			policy = new PolicyBean(policyNumber, policyPremium, accountNumber);
		} catch (JdbcException | SQLException e) {
			throw new IOException("You Have Not Created any policy" + e.getMessage());
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				throw new IOException("Unable to Close Statement Object, There is Some Error");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				throw new IOException("Unable to close Connection Object, There is Some Error");
			}
		}

		return policy;
	}

	@Override
	public List<PolicyGeneration> generateReport(int accountNumber1) throws IOException {
		List<PolicyGeneration> generatedList = new ArrayList<>();
		ResultSet resultSet = null;

		try {
			connection = JdbcConfigure.getConnection();
			statement = connection.prepareStatement(QuaryDetails.generatedReport);
			statement.setInt(1, accountNumber1);

			while (resultSet.next()) {
				String policyHolderName = resultSet.getString(1);
				String holderStreet = resultSet.getString(2);
				String holderCity = resultSet.getString(3);
				String holderState = resultSet.getString(4);
				int holderPinCode = resultSet.getInt(5);
				String holderBusinessSegment = resultSet.getString(6);
				String policyQuestion = resultSet.getString(7);
				String policyAnswer = resultSet.getString(8);
				double policyPremium = resultSet.getDouble(9);

				PolicyGeneration generation = new PolicyGeneration(policyHolderName, holderStreet, holderCity,
						holderState, holderPinCode, holderBusinessSegment, policyQuestion, policyAnswer, policyPremium);
				generatedList.add(generation);
			}
		} catch (JdbcException | SQLException e) {
			throw new IOException("You Have Not Created any policy" + e.getMessage());
		} finally {
			try {
				statement.close();
			} catch (SQLException e) {
				throw new IOException("Unable to Close Statement Object, There is Some Error");
			}
			try {
				connection.close();
			} catch (SQLException e) {
				throw new IOException("Unable to close Connection Object, There is Some Error");
			}
		}

		return generatedList;
	}

}

package com.cg.support;

import java.util.List;

import com.cg.beans.PolicyBean;
import com.cg.exception.IOException;
import com.cg.service.InsuranceService;
import com.cg.service.InsuranceServiceImpl;



public class DisplayPolicy {
	
	InsuranceService service=new InsuranceServiceImpl();
	public List<PolicyBean> viewPolicyDetails() throws IOException{
		
		List<PolicyBean> list=null;
		try {
			list=service.viewPolicyDetails();
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
		
		return list;
		
	}
	public PolicyBean getPolicy(String userName)throws IOException {
		
		return service.getPolicy(userName);
	}
}

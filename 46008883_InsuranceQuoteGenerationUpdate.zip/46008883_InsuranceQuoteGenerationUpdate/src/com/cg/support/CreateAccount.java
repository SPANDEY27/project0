package com.cg.support;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.beans.Account;
import com.cg.exception.IOException;
import com.cg.service.InsuranceService;
import com.cg.service.InsuranceServiceImpl;

public class CreateAccount {
	Scanner scanner = null;
	int accountNumber = 0;
	InsuranceService service = new InsuranceServiceImpl();

	public int createAccount(String userName) {
		int accountNumber = 0;
		String insuredHolderName = "";
		String insuredHolderStreet = "";
		String insuredHolderCity = "";
		String insuredHolderState = "";
		int insuredPincode = 0;
		String businessType = "";
		boolean zipFlag = false;
		scanner = new Scanner(System.in);
		System.out.println("Enter Account Number");
		accountNumber = scanner.nextInt();

		System.out.println("Enter insured Name: ");
		insuredHolderName = scanner.nextLine();

		System.out.println("Enter insured Street: ");
		insuredHolderStreet = scanner.nextLine();

		System.out.println("Enter insured City: ");
		insuredHolderCity = scanner.nextLine();

		System.out.println("Enter insured State: ");
		insuredHolderState = scanner.nextLine();

		do {
			System.out.println("Enter insured Zip: ");
			scanner = new Scanner(System.in);
			try {

				insuredPincode = scanner.nextInt();
				zipFlag = true;

			} catch (InputMismatchException e) {

				System.err.println("Enter digits only");
				zipFlag = false;
			}

		} while (!zipFlag);

		scanner.nextLine();

		System.out.println("Enter business Segment: ");
		businessType = scanner.nextLine();
		Account accounts = new Account(accountNumber, insuredHolderName, insuredHolderStreet, insuredHolderCity,
				insuredHolderState, insuredPincode, businessType, userName);
		try {
			accountNumber = service.createAccount(accounts);
		} catch (IOException e) {

			e.printStackTrace();
		}

		return accountNumber;

	}
}

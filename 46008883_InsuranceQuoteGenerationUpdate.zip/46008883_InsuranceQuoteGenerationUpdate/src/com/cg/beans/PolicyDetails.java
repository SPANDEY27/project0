package com.cg.beans;

public class PolicyDetails {

	private int policyNumber;
	private String questionID;
	private String answer;

	public PolicyDetails() {
		
	}

	public PolicyDetails(int policyNumber, String questionID, String answer) {
		super();
		this.policyNumber = policyNumber;
		this.questionID = questionID;
		this.answer = answer;
	}



	public int getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(int policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getQuestionID() {
		return questionID;
	}

	public void setQuestionID(String questionID) {
		this.questionID = questionID;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
	
}

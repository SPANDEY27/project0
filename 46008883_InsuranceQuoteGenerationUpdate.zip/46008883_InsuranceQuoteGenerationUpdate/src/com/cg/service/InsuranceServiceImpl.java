package com.cg.service;

import java.util.List;

import com.cg.beans.Account;
import com.cg.beans.PolicyBean;
import com.cg.beans.PolicyDetails;
import com.cg.beans.PolicyGeneration;
import com.cg.beans.UserDetails;
import com.cg.dao.DaoImplementation;
import com.cg.dao.DaoLayer;
import com.cg.exception.IOException;

public class InsuranceServiceImpl implements InsuranceService {

	DaoLayer insuranceDao = new DaoImplementation();

	@Override
	public String validLogIn(UserDetails details) throws IOException {

		return insuranceDao.validLogIn(details);
	}

	@Override
	public int createAccount(Account accounts) throws IOException {

		return insuranceDao.createAccount(accounts);
	}

	@Override
	public boolean getUserName(String userName) throws IOException {

		return insuranceDao.getUserName(userName);
	}

	@Override
	public int addProfile(UserDetails role) throws IOException {

		return insuranceDao.addProfile(role);
	}

	@Override
	public boolean existAccount(int accountNumber) throws IOException {

		return insuranceDao.existAccount(accountNumber);
	}

	@Override
	public String getBuisnessSegment(int accountNumber) throws IOException {

		return insuranceDao.getBuisnessSegment(accountNumber);
	}

	@Override
	public List<String> getQuestions(String buisnessSegId) throws IOException {

		return insuranceDao.getQuestions(buisnessSegId);
	}

	@Override
	public List<String> getAnswer(String string) throws IOException {
		return insuranceDao.getAnswer(string);
	}

	@Override
	public int getWeightage(String string, String option) throws IOException {
		return insuranceDao.getWeightage(string, option);
	}

	@Override
	public int insertPolicy(PolicyBean policy) throws IOException {
		return insuranceDao.insertPolicy(policy);
	}

	@Override
	public String getQuesId(String question) throws IOException {
		return insuranceDao.getQuesId(question);
	}

	@Override
	public List<String> getQuestionId(String buisnessSegId) throws IOException {

		return insuranceDao.getQuestionId(buisnessSegId);
	}

	@Override
	public void insertPolicyDetails(PolicyDetails policyDetails) throws IOException {
		insuranceDao.insertPolicyDetails(policyDetails);

	}

	@Override
	public List<PolicyBean> viewPolicyDetails() throws IOException {
		return insuranceDao.viewPolicyDetails();
	}

	@Override
	public List<PolicyGeneration> generateReport(int accountNumber1) throws IOException {

		return insuranceDao.generateReport(accountNumber1);
	}

	@Override
	public PolicyBean getPolicy(String userName) throws IOException {
		return insuranceDao.getPolicy(userName);
	}

	@Override
	public String validUser(UserDetails role) throws IOException {
		
		return insuranceDao.validLogIn(role);
	}

	
}

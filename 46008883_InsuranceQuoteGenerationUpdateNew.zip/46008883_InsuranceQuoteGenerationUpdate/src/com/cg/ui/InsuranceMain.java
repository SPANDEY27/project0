package com.cg.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.beans.UserDetails;
import com.cg.classes.Admin;
import com.cg.classes.Agent;
import com.cg.classes.Insurance;
import com.cg.exception.IOException;
import com.cg.service.InsuranceService;
import com.cg.service.InsuranceServiceImpl;



public class InsuranceMain {
	
	public static void main(String[] args) {
		Insurance insured=new Insurance();
		Admin admin=new Admin();
		Agent agent=new Agent();
		InsuranceService service=new InsuranceServiceImpl();
		System.out.println("******Insurance Quote Generation System******");
		Scanner scanner = null;

		boolean choiceFlag = false;
		do {

			scanner = new Scanner(System.in);
			System.out.println("1. Login");
			System.out.println("2. Exit");
			System.out.println("Enter choice: ");
			int input = 0;
			try {
				input = scanner.nextInt();
				choiceFlag = true;
				switch (input) {
				case 1:
					scanner.nextLine();
					String userName = "";
					String password = "";
					String validUser = "";
					System.out.println("Enter Username: ");
					userName = scanner.nextLine();
					System.out.println("Enter password: ");
					password = scanner.nextLine();
					UserDetails role = new UserDetails(userName, password);
					try {
						validUser = service.validUser(role);
						if (validUser == null) {
							System.err.println("User not found");
						} else {
							System.out.println("You are logged in as " + validUser);
							// System.out.println(validUser);
							validUser = validUser.trim();
							if (validUser.equals("Insured")) {
								insured.Insurance(userName);
								// System.out.println(userFlag);

							} else if (validUser.equals("Agent")) {
								agent.agent(userName);
							} else {
								admin.admin(userName);
							}
						}
					} catch (IOException e) {
						System.err.println(e.getMessage());
					}
					break;

				default:
					break;
				}

			} catch (InputMismatchException e) {

				System.err.println("Enter only digits");
				choiceFlag = false;
			}

		} while (!choiceFlag);
		scanner.close();
	}

	}


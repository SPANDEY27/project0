package com.cg.support;

import java.util.Scanner;

import com.cg.beans.UserDetails;
import com.cg.exception.IOException;
import com.cg.service.InsuranceService;
import com.cg.service.InsuranceServiceImpl;

public class ProfileCreation {
	public void profileCreation() throws IOException {

		InsuranceService service = new InsuranceServiceImpl();
		Scanner scanner = null;
		String userName = "";
		String password = "";
		String roleCode = "";

		UserDetails user = new UserDetails(userName, password, roleCode);
		try {
			int record = service.addProfile(user);
			System.out.println(record + " profile inserted.");
		} catch (IOException e) {
			System.err.println(e.getMessage());
		} finally {
			scanner.close();
		}

	}

}

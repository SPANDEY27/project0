package com.cg.beans;

public class PolicyBean {

	private int policyNumber;
	private double policyPremium;
	private int accountNumber;
	private String username;
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public PolicyBean(int policyNumber, double policyPremium, int accountNumber) {
		super();
		this.policyNumber = policyNumber;
		this.policyPremium = policyPremium;
		this.accountNumber = accountNumber;
		
	}

	public int getPolicyNumber() {
		return policyNumber;
	}
	public PolicyBean(double policyPremium, int accountNumber) {
		super();
		this.policyPremium = policyPremium;
		this.accountNumber = accountNumber;
	}


	public void setPolicyNumber(int policyNumber) {
		this.policyNumber = policyNumber;
	}

	public double getPolicyPremium() {
		return policyPremium;
	}

	public void setPolicyPremium(double policyPremium) {
		this.policyPremium = policyPremium;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	@Override
	public String toString() {
		return "PolicyBean [policyNumber=" + policyNumber + ", policyPremium=" + policyPremium + ", accountNumber="
				+ accountNumber + ", username=" + username + "]";
	}
	
	
	
}

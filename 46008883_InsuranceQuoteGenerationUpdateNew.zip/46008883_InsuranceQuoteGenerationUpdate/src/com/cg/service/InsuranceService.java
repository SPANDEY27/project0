package com.cg.service;

import java.util.List;

import com.cg.beans.Account;
import com.cg.beans.PolicyBean;
import com.cg.beans.PolicyDetails;
import com.cg.beans.PolicyGeneration;
import com.cg.beans.UserDetails;
import com.cg.exception.IOException;



public interface InsuranceService {
	
	String validUser(UserDetails role) throws IOException;

	String validLogIn(UserDetails details) throws IOException;

	int createAccount(Account accounts) throws IOException;

	boolean getUserName(String userName) throws IOException;

	int addProfile(UserDetails role) throws IOException;
	
	
	boolean existAccount(int accountNumber) throws IOException;

	String getBuisnessSegment(int accountNumber) throws IOException;

	List<String> getQuestions(String buisnessSegId) throws IOException;

	List<String> getAnswer(String string) throws IOException;

	int getWeightage(String string, String option) throws IOException;

	int insertPolicy(PolicyBean policy) throws IOException;

	String getQuesId(String question) throws IOException;

	List<String> getQuestionId(String buisnessSegId) throws IOException;

	void insertPolicyDetails(PolicyDetails policyDetails) throws IOException;

	List<PolicyBean> viewPolicyDetails() throws IOException;

	List<PolicyGeneration> generateReport(int accountNumber1) throws IOException;

	PolicyBean getPolicy(String userName) throws IOException;

}
